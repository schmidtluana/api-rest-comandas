package com.example.trabalho_suficiencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabalhoSuficienciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
