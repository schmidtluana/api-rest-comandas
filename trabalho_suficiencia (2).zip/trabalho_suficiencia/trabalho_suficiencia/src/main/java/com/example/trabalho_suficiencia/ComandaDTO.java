package com.example.trabalho_suficiencia;
import lombok.Data;

@Data
public class ComandaDTO {
    private Long id;

    private Long idUsuario;

    private String nomeUsuario;

    private String telefoneUsuario;

    public ComandaDTO(ComandaEntity comandaEntity) {
        this.id = comandaEntity.getId();
        this.idUsuario = comandaEntity.getIdUsuario();
        this.nomeUsuario = comandaEntity.getNomeUsuario();
        this.telefoneUsuario = comandaEntity.getTelefoneUsuario();
    }
}
