package com.example.trabalho_suficiencia;
import lombok.Data;

@Data
public class LoginDTO {

    private String user;
    private String pass;

}