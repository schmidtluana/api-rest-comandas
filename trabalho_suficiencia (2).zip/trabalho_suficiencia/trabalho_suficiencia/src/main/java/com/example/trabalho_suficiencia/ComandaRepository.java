package com.example.trabalho_suficiencia;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ComandaRepository extends JpaRepository<ComandaEntity, Long> {
    List<ComandaEntity> findByNomeUsuario(String nomeUsuario );
    List<ComandaEntity> findByTelefoneUsuario(String telefoneUsuario);
}