package com.example.trabalho_suficiencia;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class ComandaService {

    @Autowired
    @Lazy
    private ComandaRepository comandaRepository;
    @Autowired
    private ProdutoRepository produtoRepository;



    @Transactional(propagation = Propagation.REQUIRED)
    public ComandaEntity buscarPorComanda(Long id) {
        ComandaEntity comandaEntity = comandaRepository.findById(id).orElse(null);
        return comandaEntity;
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public List<ComandaDTO> buscarComandas() {

        List<ComandaDTO> comandasDTO = new ArrayList<>();

        List<ComandaEntity> comandas = comandaRepository.findAll();

        if (comandas != null) {
            comandas.forEach(comanda -> comandasDTO.add(new ComandaDTO(comanda)));
        }
        return comandasDTO;
    }
}
