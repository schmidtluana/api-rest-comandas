package com.example.trabalho_suficiencia;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.Api;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
@Api(value = "Comandas", protocols = "http")
public class ComandasRestController {

    @Autowired
    private ObjectMapper objectMapper;

    private final ComandaRepository comandaRepository;
    private final ProdutoRepository produtoRepository;

    @Autowired
    @Lazy
    private ComandaService usuarioService;

    public ComandasRestController(ComandaRepository usuarioRepository, ProdutoRepository produtoRepository) {
        this.comandaRepository = usuarioRepository;
        this.produtoRepository = produtoRepository;
    }

    @GetMapping("/comandas")
    public List<ComandaDTO> listar() {
        List<ComandaDTO> comandaDTOS = usuarioService.buscarComandas();
        return comandaDTOS;
    }

    @GetMapping("/comandas/{id}")
    public ComandaEntity obterPorIdComanda(@PathVariable Long id) {
        ComandaEntity comanda = usuarioService.buscarPorComanda(id);
        return comanda;
    }

    @PostMapping("/comandas")
    public ComandaEntity cadastrarComanda(@RequestBody ComandaEntity comanda) {
       ComandaEntity novaComanda = comandaRepository.save(comanda);
        return novaComanda;
    }

    @PutMapping("comandas/{id}")
    public ResponseEntity<ComandaEntity> atualizarComanda(@PathVariable Long id, @RequestBody ComandaEntity newComanda) {
        ComandaEntity clienteExistente = comandaRepository.findById(id).orElse(null);
        if (clienteExistente != null) {
            Hibernate.initialize(clienteExistente.getProdutos());
            clienteExistente.setProdutos(newComanda.getProdutos());
            comandaRepository.save(clienteExistente);
            return ResponseEntity.ok(clienteExistente);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @DeleteMapping("/comandas/{id}")
    public ResponseEntity<?> excluir(@PathVariable Long id) {
        ComandaEntity clienteExistente = comandaRepository.findById(id).orElse(null);
        if (clienteExistente != null) {
            comandaRepository.delete(clienteExistente);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
//
//   // Observe que o parâmetro @RequestBody indica que o corpo da requisição HTTP deve ser
//    // convertido em um objeto Cliente. Já o retorno ResponseEntity permite definir o status da resposta HTTP, cabeçalhos e corpo da resposta.

}
