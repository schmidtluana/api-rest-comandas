package com.example.trabalho_suficiencia;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProdutoRepository extends JpaRepository<ProdutoComandaEntity, Long> {
    List<ProdutoComandaEntity> findByNome(String nome);
}